/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfacepresentation;

import java.util.ArrayList;

/**
 *
 * @author USER
 */
class Vacation {
    private int totaldays; 
    private String vacationName; 
    private ArrayList<Experience> experiences = new ArrayList<>(); 
    private ArrayList<Integer> participants = new ArrayList<>(); 

    
    
    
    @Override
    public String toString(){
        String packageName = vacationName; 
        packageName = packageName + " [ "; 
        for (int i = 0; i < getNumberOfExperiences(); i++)
            if(i < getNumberOfExperiences()-1)
                packageName = packageName + getExperienceAt(i).getExperienceName() + ": " + this.getParticipantsAt(i) + ", "; 
                
            else 
            packageName = packageName + getExperienceAt(i).getExperienceName()+ ": " + this.getParticipantsAt(i); 
        
        packageName = packageName + "]"; 
        packageName = packageName + " " + totaldays + " days $" + this.computeTotalCost();
        return packageName; 
        
        //return vacationName; 
        //packageName = packageName + ": " + totaldays + " [ "; 
    }
    
    
    public int getNumberOfExperiences(){
        return experiences.size(); 
    }
    
    public Experience getExperienceAt(int index){
        return experiences.get(index); 
    }
    
    public int getParticipantsAt(int index){
        return participants.get(index); 
    }
    
    public void setParticipantsAt(int index, int newParticipants){
        participants.set(index, newParticipants); 
    }
    
    
    public void addExperience(Experience newExperience, int howManyPeople){
        experiences.add(newExperience); 
        this.participants.add(howManyPeople); 
    }
    
    
    
    
    
    public void removeExperience(int index){
        experiences.remove(index); 
        participants.remove(index); 
    }
    
    
    public void removeExperience(Experience e){
        int index; 
        index = experiences.indexOf(e); 
        if(index != -1)
            removeExperience(index); 
        else
            System.err.println("Experience does not exist.");
    }
    
    
    public void removeAllExperiences(){
        experiences.clear(); 
        participants.clear();
    }
    
    
    public double computeTotalCost(){
        double cost = 0; 
        for(int i = 0; i < experiences.size(); i++)
            cost = cost + participants.get(i) * experiences.get(i).getPrice(); 
        
        return cost; 
    }
    
    
    public int getTotaldays() {
        return totaldays;
    }

    public void setTotaldays(int totaldays) {
        this.totaldays = totaldays;
    }

    public String getVacationName() {
        return vacationName;
    }

    public void setVacationName(String vacationName) {
        this.vacationName = vacationName;
    }

    
    
    
    
}
