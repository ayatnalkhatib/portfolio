/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfacepresentation;

import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

/**
 *
 * @author USER
 */
public class InterfacePresentation {

    /**
     * @param args the command line arguments
     */
     
    public static ArrayList<Vacation> packages = new ArrayList<>(); 
    
    public static ArrayList<Experience> experiences = new ArrayList<>(); 
    
    

    
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        
         
        
        Vacation info; 
        
     
    
    info = new Vacation();
    info.setVacationName("First Vacation");
    info.setTotaldays(5);
    
    
    
     Experience first, second, third; 
     
     first = new Experience();
     first.setExperienceName("Aquarium Tour"); 
     first.setProvider("Starfish sightings");
     first.setPrice(250);
     
//     first = new Experience(); 
//     first.setExperienceName("Boat Trip"); 
//     first.setPrice(115);
//     
//     first = new Experience(); 
//     first.setExperienceName("Botanical Garden"); 
//     first.setPrice(80);
//     
//     first = new Experience(); 
//     first.setExperienceName("Hiking"); 
//     first.setPrice(44);
//     
     second = new Experience(); 
     second.setExperienceName("Snow Boarding"); 
     second.setProvider("Snowy Alps");
     second.setPrice(44); 
     
     third = new Experience(); 
     third.setExperienceName("Picnic"); 
     third.setProvider("Sunflower");
     third.setPrice(44); 
     
     
//     second = new Experience(); 
//     second.setExperienceName("Paragliding"); 
//     second.setPrice(112); 
//     
//     second = new Experience(); 
//     second.setExperienceName("Sightseeing on a Train"); 
//     second.setPrice(108); 
//     
//     second = new Experience(); 
//     second.setExperienceName("Walking"); 
//     second.setPrice(0);
     
     info.addExperience(first, 3);
     info.addExperience(second, 5);
     info.addExperience(third, 6); 
     
     
     packages.add(info); 
     
     experiences.add(first); 
     experiences.add(second); 
     experiences.add(third); 
     
     
     
     info = new Vacation(); 
     info.setVacationName("Tropical vacation");
     info.setTotaldays(7);
     packages.add(info);//line used to add to list
     
     
     
     
     
//     System.out.println("Vacation " + info.getVacationName() + " (" + info.getTotaldays() + " days");
//             for(int i = 0; i < info.getNumberOfExperiences(); i++){
//                 Experience e = info.getExperienceAt(i); 
//                 System.out.println("\t" + e.getExperienceName() + "for" + info.getParticipantsAt(i) +
//                 " people provided by " + e.getProvider() + "($" + e.getPrice() + ")");
//             }
     
        
        
        
        
        
        
        
        
       /*    Opened Tab Part           */
       
       
        
        JFrame window1, window2; 
        
        window1 = new JFrame("Opened Window"); 
        
        PresentationPanel panel = new PresentationPanel(); 
        window1.add(panel); 
        
        window1.setLocation(105,95);
       // window1.setSize(664, 550); 
        window1.setSize(600, 500);
        window1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        window1.setVisible(true);
        
        //-----------------------------------------------------------------
        
        window2 = new JFrame("Opened Experiences"); 
        
        ExperiencePanel exppanel = new ExperiencePanel(); 
        window2.add(exppanel); 
        
        window2.setLocation(695,95);
        window2.setSize(600, 500); 
        window2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        window2.setVisible(true);
        
        
        
        System.out.println("Hello World");
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
