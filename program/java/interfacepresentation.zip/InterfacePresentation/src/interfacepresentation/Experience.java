/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfacepresentation;

/**
 *
 * @author USER
 */
class Experience {
    
    private String experienceName; 
    private double price; 
    private String provider; 

    
    public String toString(){
        return experienceName + " [ $" + price + ", " + provider + "]"; 
    }
    
    
    
    
     public String getExperienceName() {
        return experienceName;
    }

    public void setExperienceName(String experienceName) {
        this.experienceName = experienceName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }
    
    
    
    
}
