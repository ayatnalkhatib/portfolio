/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfacepresentation;

/**
 *
 * @author USER
 */
public class ArrayVacation {
    
    private String name; 
    private int days; 
    private Experience experiences[] = new Experience[1000]; 
    private int[] participants = new int[1000]; 
    private int sizeExp; 
    
    public int getNumberOfExperiences(){
        return sizeExp; 
    }
    
    
    public Experience getExperienceAt(int index){
        return experiences[index]; 
    }
    
    
    public int getParticipantsAt(int index){
        return participants[index];
    }
    
    
    
    public void addExperience(Experience newExperience, int howManyPeople){
        experiences[sizeExp] = newExperience; 
        this.participants[sizeExp] = howManyPeople; 
        sizeExp++; 
    }
    
    
    
    public void removeExperience(int index){
        for (int i = index; i + 1 < sizeExp; i++){
            experiences[i] = experiences[i + 1]; 
            participants[i] = participants[i + 1]; 
        } 
        sizeExp--; 
    }
    
    
    
    public void removeExperience(Experience e){
        for(int i = 0; i < sizeExp; i++){
            if(experiences[i] == e){
                removeExperience(i); 
                return; 
            }
        }
        System.err.println("Experience not found");
    }
    
    
    
    
     public double computeTotalCost(){
        double cost = 0; 
        for(int i = 0; i < sizeExp; i++)
            cost = cost + participants[i] * experiences[i].getPrice(); 
        
        return cost; 
    }
    
    
    
    
    
    
    
    
    
    
    
}
