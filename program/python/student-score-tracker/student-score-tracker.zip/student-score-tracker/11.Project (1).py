# Step 1 - Create a class called "Students"
class Students:
    # Step 2 - Define the initializer
    def __init__(self, firstname, lastname, tnumber):
        self.FirstName = firstname
        self.LastName = lastname
        self.TNumber = tnumber
        self.Grade = []  # Store scores

    # Step 4 - Define methods for the object
    def add_score(self, score):
        if score != "":
            self.Grade.append(float(score))

    def RunningAverage(self):
        total = sum(self.Grade)
        count = len(self.Grade)
        return total / count if count != 0 else 0

    def TotalAverage(self):
        total = sum(self.Grade)
        count = len(self.Grade)
        return total / count if count != 0 else 0

    def LetterGrade(self):
        avg = self.TotalAverage()
        if avg >= 90:
            return 'A'
        if avg >= 80:
            return 'B'
        if avg >= 70:
            return 'C'
        if avg >= 60:
            return 'D'
        return 'F'

# Step 1 - Define the class object "StudentList"
class StudentList:
    # Step 2 - Define initializer
    def __init__(self):
        self.StudentList = []

    # Step 3 - Add a student
    def add_student(self, FirstName, LastName, TNumber):
        mystudent = Students(FirstName, LastName, TNumber)
        self.StudentList.append(mystudent)

    # Step 4 - Find student by TNumber
    def find_student(self, TNumber):
        for student in self.StudentList:
            if student.TNumber == TNumber:
                return student
        return None

    # Step 5 - Print student list
    def print_ball_list(self):
        print("{:>14s}{:>14s}{:>14s}{:>14s}".format("Type", "FirstName", "LastName", "TNumber"))
        for s in self.StudentList:
            print("{:>14s}{:>14s}{:>14s}{:>14s}".format(
                "Student",
                s.FirstName,
                s.LastName,
                s.TNumber
            ))
        print()
        print("{} Students in list".format(len(self.StudentList)))
        print()

    # Step 6 - Add students from file
    def add_students_from_file(self, filename):
        with open(filename, "r") as f:
            for line in f:
                y = line.strip().split(",")
                if len(y) >= 3:
                    self.add_student(y[0].strip(), y[1].strip(), y[2].strip())

    # Step 7 - Add scores from file
    def add_scores_from_file(self, filename):
        with open(filename, "r") as f:
            for line in f:
                y = line.strip().split(",")
                if len(y) == 2:
                    student = self.find_student(y[0].strip())
                    if student:
                        student.add_score(y[1].strip())


# Create student list
mystudentlist = StudentList()

# Add students from file
mystudentlist.add_students_from_file("11.Project Students.txt")

# Add scores from file
mystudentlist.add_scores_from_file("11.Project Scores.txt")

# Print results
mystudentlist.print_ball_list()
